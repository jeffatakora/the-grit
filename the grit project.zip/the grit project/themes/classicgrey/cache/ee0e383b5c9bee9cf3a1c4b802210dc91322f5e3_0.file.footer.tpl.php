<?php
/* Smarty version 3.1.31, created on 2018-03-22 12:39:17
  from "C:\wamp\www\vvu\bpm\formtools\themes\classicgrey\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5ab395e585b8a6_48467320',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ee0e383b5c9bee9cf3a1c4b802210dc91322f5e3' => 
    array (
      0 => 'C:\\wamp\\www\\vvu\\bpm\\formtools\\themes\\classicgrey\\footer.tpl',
      1 => 1521571264,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ab395e585b8a6_48467320 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_ft_include')) require_once 'C:\\wamp\\www\\vvu\\bpm\\formtools\\global\\smarty_plugins\\function.ft_include.php';
if (!is_callable('smarty_function_show_page_load_time')) require_once 'C:\\wamp\\www\\vvu\\bpm\\formtools\\global\\smarty_plugins\\function.show_page_load_time.php';
?>
              </div>
            </div>
          </div>
        </div>

        <div id="left" class="pad_top_large">
            <?php echo smarty_function_ft_include(array('file'=>"menu.tpl"),$_smarty_tpl);?>

        </div>
      </div>

      <div class="clear"></div>

    </div>
  </div>
</div>


<?php if ($_smarty_tpl->tpl_vars['footer_text']->value != '' || $_smarty_tpl->tpl_vars['g_enable_benchmarking']->value) {?>
  <div id="footer">
    <?php echo (($tmp = @$_smarty_tpl->tpl_vars['footer_text']->value)===null||$tmp==='' ? '' : $tmp);?>

    <?php echo smarty_function_show_page_load_time(array(),$_smarty_tpl);?>

  </div>
<?php }?>

</body>
</html>
<?php }
}
