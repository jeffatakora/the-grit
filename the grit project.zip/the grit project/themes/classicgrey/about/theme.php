<?php

$theme_name = "Classic Grey";
$theme_author = "Ben Keen";
$theme_author_email = "ben.keen@gmail.com";
$theme_link = "https://themes.formtools.org";
$theme_description = "A remodelling of the old grey-styled Form Tools 1.x theme.";
$theme_version = "2.0.5";
$theme_uses_swatches = "no";
