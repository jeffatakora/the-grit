<?php
/* Smarty version 3.1.31, created on 2018-03-22 11:45:50
  from "C:\wamp\www\vvu\bpm\formtools\global\smarty_plugins\eval.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5ab3895e998890_24578091',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '97cb97fb5b9e4ce432509d86111956b466284832' => 
    array (
      0 => 'C:\\wamp\\www\\vvu\\bpm\\formtools\\global\\smarty_plugins\\eval.tpl',
      1 => 1521571262,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ab3895e998890_24578091 (Smarty_Internal_Template $_smarty_tpl) {
$_template = new Smarty_Internal_Template('eval:'.$_smarty_tpl->tpl_vars['eval_str']->value, $_smarty_tpl->smarty, $_smarty_tpl);echo $_template->fetch();
}
}
