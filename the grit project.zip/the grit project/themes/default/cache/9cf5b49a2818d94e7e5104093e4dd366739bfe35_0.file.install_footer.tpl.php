<?php
/* Smarty version 3.1.31, created on 2018-03-22 11:42:11
  from "C:\wamp\www\vvu\bpm\formtools\install\templates\install_footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5ab38883ae31d5_81935928',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9cf5b49a2818d94e7e5104093e4dd366739bfe35' => 
    array (
      0 => 'C:\\wamp\\www\\vvu\\bpm\\formtools\\install\\templates\\install_footer.tpl',
      1 => 1521571262,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ab38883ae31d5_81935928 (Smarty_Internal_Template $_smarty_tpl) {
?>
</div>
<div class="clear"></div>

<div id="footer">
	<ul>
		<li><a href="https://formtools.org" target="_blank">formtools.org</a></li>
		<li><a href="https://docs.formtools.org/installation/" target="_blank"><?php echo $_smarty_tpl->tpl_vars['LANG']->value['phrase_installation_help'];?>
</a></li>
		<li><a href="https://docs.formtools.org" target="_blank"><?php echo $_smarty_tpl->tpl_vars['LANG']->value['word_documentation'];?>
</a></li>
		<li class="colN"><a href="https://forums.formtools.org" target="_blank"><?php echo $_smarty_tpl->tpl_vars['LANG']->value['phrase_problems_questions_forum'];?>
</a></li>
	</ul>
	<div class="clear"></div>
</div>

<div class="clear"></div>
</div>

</body>
</html>
<?php }
}
