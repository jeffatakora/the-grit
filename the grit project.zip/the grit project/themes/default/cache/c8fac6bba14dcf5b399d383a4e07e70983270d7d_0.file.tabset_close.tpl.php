<?php
/* Smarty version 3.1.31, created on 2018-03-22 11:46:58
  from "C:\wamp\www\vvu\bpm\formtools\themes\default\tabset_close.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5ab389a26860d6_60662475',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c8fac6bba14dcf5b399d383a4e07e70983270d7d' => 
    array (
      0 => 'C:\\wamp\\www\\vvu\\bpm\\formtools\\themes\\default\\tabset_close.tpl',
      1 => 1521571262,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ab389a26860d6_60662475 (Smarty_Internal_Template $_smarty_tpl) {
?>
  </div><?php }
}
