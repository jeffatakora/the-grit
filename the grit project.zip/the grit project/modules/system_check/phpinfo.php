<?php

require_once("../../global/library.php");

$module = FormTools\Modules::initModulePage("admin");

phpinfo();
