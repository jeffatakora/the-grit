<?php

require("../../global/library.php");

$module = FormTools\Modules::initModulePage("admin");

$module->displayPage("templates/help.tpl");
