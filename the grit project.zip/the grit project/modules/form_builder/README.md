## Form Builder module

The Form Builder lets you create actual forms on your website. Check out the documentation for more information.


### Documentation

- [https://docs.formtools.org/modules/form_builder/](https://docs.formtools.org/modules/form_builder/)


### Other Links

- [Available Form Tools modules](https://modules.formtools.org/)
- [About Form Tools modules](https://docs.formtools.org/userdoc/modules/) 
- [Installation instructions](https://docs.formtools.org/userdoc/modules/installing/)
- [Upgrading](https://docs.formtools.org/userdoc/modules/upgrading/)
